<?php 
 class person{
 	public $name;
 		public $age;
 		public $city;

 		function __construct($name="no name",$age="0",$city="no"){
 			$this->name = $name;
 				$this->age = $age;
 				$this->city = $city;
 		}
 		function show(){
 			echo $this->name . " -> " ."age-" . $this->age  . "->" . $this->city . "<br/>";
 		}
 }
 $p1 =new person();
 $p2 =new person("raja",21,"mumbai");
 $p3 =new person("faruki",24,"udisha");
 $p4 =new person("dev",12,"patna");

 $p1 ->show();
 $p2 ->show();
 $p3 ->show();
 $p4 ->show();
?>